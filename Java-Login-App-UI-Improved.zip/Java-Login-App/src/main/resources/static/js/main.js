/**
 * Employee Portal — shared front-end behaviour
 * - Password show/hide toggle
 * - Bootstrap-style client-side validation feedback
 * - Loading state on form submit buttons
 * No backend logic here: field names / endpoints are untouched.
 */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    initPasswordToggles();
    initFormValidation();
    initAutoDismissAlerts();
  });

  /* ---- Show / hide password ---- */
  function initPasswordToggles() {
    document.querySelectorAll('.toggle-password').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var targetId = btn.getAttribute('data-target');
        var input = document.getElementById(targetId);
        if (!input) return;
        var isHidden = input.type === 'password';
        input.type = isHidden ? 'text' : 'password';
        var icon = btn.querySelector('i');
        if (icon) {
          icon.classList.toggle('fa-eye', !isHidden);
          icon.classList.toggle('fa-eye-slash', isHidden);
        }
        btn.setAttribute('aria-label', isHidden ? 'Hide password' : 'Show password');
      });
    });
  }

  /* ---- Validation + loading button on submit ---- */
  function initFormValidation() {
    var forms = document.querySelectorAll('form[data-validate="true"]');
    forms.forEach(function (form) {
      form.addEventListener('submit', function (event) {
        if (!form.checkValidity()) {
          event.preventDefault();
          event.stopPropagation();
          form.classList.add('was-validated');
          var firstInvalid = form.querySelector(':invalid');
          if (firstInvalid) firstInvalid.focus();
          return;
        }
        form.classList.add('was-validated');
        var submitBtn = form.querySelector('button[type="submit"]');
        if (submitBtn && submitBtn.classList.contains('btn-loading')) {
          submitBtn.classList.add('is-loading');
          submitBtn.disabled = true;
        }
      });
    });
  }

  /* ---- Auto-dismiss success/error alerts after a while ---- */
  function initAutoDismissAlerts() {
    document.querySelectorAll('.alert-ep[data-autohide="true"]').forEach(function (alertEl) {
      setTimeout(function () {
        alertEl.style.transition = 'opacity .4s ease';
        alertEl.style.opacity = '0';
        setTimeout(function () { alertEl.remove(); }, 400);
      }, 6000);
    });
  }
})();
