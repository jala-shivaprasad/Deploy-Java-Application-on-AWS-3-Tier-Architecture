<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<% request.setAttribute("pageTitle", "Employee Portal | Dashboard"); %>
<jsp:include page="/pages/common/header.jsp" />

<section class="section-pad pt-4">
  <div class="container">

    <div class="dash-header fade-up mb-5">
      <%
        Object usernameAttr = request.getAttribute("username");
        String usernameStr = usernameAttr != null ? String.valueOf(usernameAttr) : "";
        String initial = usernameStr.length() > 0 ? usernameStr.substring(0, 1).toUpperCase() : "U";
      %>
      <div class="avatar-circle"><%= initial %></div>
      <div>
        <div class="text-teal fw-semibold mb-1" style="font-size:.8rem; letter-spacing:.06em; text-transform:uppercase;">Employee Dashboard</div>
        <h2 class="text-white mb-1">Welcome, ${username}</h2>
        <p class="mb-0" style="color:rgba(255,255,255,.7);">You're securely signed in to iwayQ.com | Instant Information Site.</p>
      </div>
    </div>

    <div class="mb-4">
      <span class="section-eyebrow">Quick access</span>
      <h4 class="mt-2 mb-4">Where would you like to go?</h4>
    </div>

    <div class="row g-4">
      <div class="col-6 col-md-4 col-lg-3">
        <a class="dash-tile d-block text-decoration-none" href="http://www.iwayq.com">
          <div class="dash-tile-icon"><i class="fa-solid fa-house"></i></div>
          <div class="fw-semibold">Home</div>
        </a>
      </div>
      <div class="col-6 col-md-4 col-lg-3">
        <a class="dash-tile d-block text-decoration-none" href="http://www.iwayq.com/gallery/gallery.html">
          <div class="dash-tile-icon"><i class="fa-solid fa-images"></i></div>
          <div class="fw-semibold">Gallery</div>
        </a>
      </div>
      <div class="col-6 col-md-4 col-lg-3">
        <a class="dash-tile d-block text-decoration-none" href="http://www.iwayq.com/videos/videos.html">
          <div class="dash-tile-icon"><i class="fa-solid fa-video"></i></div>
          <div class="fw-semibold">Videos</div>
        </a>
      </div>
      <div class="col-6 col-md-4 col-lg-3">
        <a class="dash-tile d-block text-decoration-none" href="http://www.iwayq.com/videos/videos.html">
          <div class="dash-tile-icon"><i class="fa-solid fa-newspaper"></i></div>
          <div class="fw-semibold">Articles</div>
        </a>
      </div>
      <div class="col-6 col-md-4 col-lg-3">
        <a class="dash-tile d-block text-decoration-none" href="http://www.iwayq.com/videos/videos.html">
          <div class="dash-tile-icon"><i class="fa-solid fa-graduation-cap"></i></div>
          <div class="fw-semibold">Tutorials</div>
        </a>
      </div>
      <div class="col-6 col-md-4 col-lg-3">
        <a class="dash-tile d-block text-decoration-none" href="http://www.iwayq.com/videos/videos.html">
          <div class="dash-tile-icon"><i class="fa-solid fa-list-check"></i></div>
          <div class="fw-semibold">Assessment</div>
        </a>
      </div>
      <div class="col-6 col-md-4 col-lg-3">
        <a class="dash-tile d-block text-decoration-none" href="http://www.iwayq.com/videos/videos.html">
          <div class="dash-tile-icon"><i class="fa-solid fa-square-poll-vertical"></i></div>
          <div class="fw-semibold">Poll &amp; Survey</div>
        </a>
      </div>
      <div class="col-6 col-md-4 col-lg-3">
        <a class="dash-tile d-block text-decoration-none" href="http://www.iwayq.com/videos/videos.html">
          <div class="dash-tile-icon"><i class="fa-solid fa-comments"></i></div>
          <div class="fw-semibold">Chat</div>
        </a>
      </div>
    </div>

  </div>
</section>

<jsp:include page="/pages/common/footer.jsp" />
